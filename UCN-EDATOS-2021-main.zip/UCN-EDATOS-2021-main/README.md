![UCN](docs/images/60x60-ucn-negro.png)


# Proyecto: Detección y reidentificación de caras en secuencias de imágenes o video
## Curso: Estructura de datos

### Integrantes

* Alumno 01 (Rol)
* Alumno 02 (Rol)

### Bitácora

[Ver Bitácora](docs/BITACORA.md)

### Resumen

<Agregar el resumen del reporte técnico>

<Colocar alguna imágen en la portada>

### Documentos

* [Reporte Técnico](docs/README.md)



