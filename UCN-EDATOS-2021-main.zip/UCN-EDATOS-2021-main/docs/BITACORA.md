# Bitácora

[(Volver)](../README.md)

| Fecha  | Objetivo  | Trabajo Realizado | Responsable | Tiempo Estimado | Tiempo Real |
|--------|-----------|-------------------|-------------|-----------------|-------------|
| 30/SEP | OBJ-01    | Leer el código de detección de caras| jbekios     | 2 horas    | 4 horas |
| 01/SEP | OBJ-01    | Buscar uso de punteros en C++ para asignación de memoria dinámica | jbekios |  0.5 horas | 0.3 horas |
| 01/SEP | OBJ-03 | Implementar lectura de imágenes utilizando las librerías de OpenCV | jbekios | 1.5 horas | 2 horas |
